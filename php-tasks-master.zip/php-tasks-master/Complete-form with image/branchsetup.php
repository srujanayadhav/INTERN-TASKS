<!DOCTYPE html>
<html>
<head>
	<title>Branch</title>
</head>
<body>
	<?php
		echo "Hello \n";
		echo("New record created");
	?>
</body>
</html>